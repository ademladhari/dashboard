import 'package:flutter/material.dart';

class charts extends StatefulWidget {
  const charts({super.key});

  @override
  State<charts> createState() => _chartsState();
}

class _chartsState extends State<charts> {
  @override
  Widget build(BuildContext context) {
    return Container();
  }
}